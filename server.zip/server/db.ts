import { drizzle } from "drizzle-orm/node-postgres";
import pg from "pg";
import * as schema from "@shared/schema";

const { Pool } = pg;
let pool: pg.Pool | undefined;
let db: any; // using any to bypass complex type constraints for now


if (!process.env.DATABASE_URL) {
  const { PGlite } = await import("@electric-sql/pglite");
  const { drizzle } = await import("drizzle-orm/pglite");

  // Use in-memory database by default, or persist to .drizzle/pglite if desired
  // Using file system persistence for better dev experience across restarts
  const client = new PGlite("./.drizzle/pglite");
  console.log("Using PGlite database at ./.drizzle/pglite");

  db = drizzle(client, { schema });
  // pool is not available in PGlite mode
} else {
  pool = new Pool({ connectionString: process.env.DATABASE_URL });
  db = drizzle(pool, { schema });
}

// @ts-ignore
export { pool, db };
